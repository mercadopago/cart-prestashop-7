<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mercadopago}prestashop>mercadopago_3ce3662af6cffea8677b4cb92dea4939'] =
'Mercado Pago';
$_MODULE['<{mercadopago}prestashop>mercadopago_b9a2e0f33da43f952a816aa78f78ee2e'] =
'Customize a experiência de pagamento dos seus clientes com um checkout seguro, rápido e fácil de instalar.';
$_MODULE['<{mercadopago}prestashop>mercadopago_0f379daaee21894a7c6453950658fe8b'] =
'Tem certeza que deseja desinstalar o módulo?';
$_MODULE['<{mercadopago}prestashop>mercadopago_a88f84d8cb58f8230240e1665058c7ff'] =
'Você tem que habilitar a extensão cURL';
$_MODULE['<{mercadopago}prestashop>mercadopago_d4423ad419d2bf8911d67aae2710b2bf'] =
'no seu servidor para instalar este módulo.';
$_MODULE['<{mercadopago}prestashop>mercadopago_aea84af3b9a9115bf366af2993aafe68'] =
'Transação em Processamento';
$_MODULE['<{mercadopago}prestashop>mercadopago_5b3f086dfa19e142c8dd3dd4c3248379'] =
'Transação Concluída';
$_MODULE['<{mercadopago}prestashop>mercadopago_f01f74aabecf111292f9b9e01027ae0c'] =
'Transação Cancelada';
$_MODULE['<{mercadopago}prestashop>mercadopago_52c8fdd11601ff4aacfacba9cb00f873'] =
'Transação Rejeitada';
$_MODULE['<{mercadopago}prestashop>mercadopago_186177a57ee4cb741ba591e0259e871f'] =
'Transação Reembolsada';
$_MODULE['<{mercadopago}prestashop>mercadopago_ab74c3411f6f46df16a6c47791be5a1b'] =
'Transação Chargedback';
$_MODULE['<{mercadopago}prestashop>mercadopago_bf40a1c10d0b4a9cb26a27593226285b'] =
'Transação em Mediação';
$_MODULE['<{mercadopago}prestashop>mercadopago_53b4d02529d11ed85eb327d5297ec1ca'] =
'Transação pendente';
$_MODULE['<{mercadopago}prestashop>mercadopago_2b39c27da5542ec1a72d8151ac607cd7'] =
'Transação Autorizada';
$_MODULE['<{mercadopago}prestashop>mercadopago_3e8bd808fa886bce4b3de20f28870f9d'] =
'Quero pagar com Mercado Pago sem custo adicional.';
$_MODULE['<{mercadopago}prestashop>mercadopago_f4818b8be3fb0dcad10b46475db2efa1'] =
'Quero pagar com cartão de crédito';
$_MODULE['<{mercadopago}prestashop>mercadopago_5edffb5efe684d534217bad198adeece'] =
'Quero pagar via boleto ou na lotérica';
$_MODULE['<{mercadopago}prestashop>homologationsettings_2488dda96f94d5e5d7f227690ed5fabc'] =
'Homologação';
$_MODULE['<{mercadopago}prestashop>abstractsettings_c9cc8cce247e49bae79f15173ce97354'] =
'Salvar';
$_MODULE['<{mercadopago}prestashop>abstractsettings_4d9ac946f92f7211e40671513c72fd09'] =
'Configurações salvas com sucesso';
$_MODULE['<{mercadopago}prestashop>abstractsettings_36ac045205b16f9bb7cd8bb5641e839d'] =
'A hora para salvar as preferências de pagamento ';
$_MODULE['<{mercadopago}prestashop>abstractsettings_81495f3842f92cd64795702e235405e6'] =
'deve ser um número inteiro.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_93027262f5c97f5faccac9eb7ef7df6d'] =
'As credenciais não podem ficar em branco e devem ser válidas.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_cbfa2a7c18db32aca0f634532701ee11'] =
'Por favor, preencha suas credenciais para habilitar o módulo.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_0a89ca4eadc203592214129f2355a257'] =
'O desconto deve ser um número inteiro e menos de 100%.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_d13e2a23135def99ea08f9a21eb663a0'] =
'O pagamento devido deve ser um número inteiro.';
$_MODULE['<{mercadopago}prestashop>standardsettings_263485bdc392a068c22db476bfb5d0f2'] =
'Configuração básica';
$_MODULE['<{mercadopago}prestashop>standardsettings_49c557074b8d2bdb3ad51b3e0a7de714'] =
'Ativar checkout';
$_MODULE['<{mercadopago}prestashop>standardsettings_d8bf0bd06048ac8cb87266046772cd15'] =
'Ative a experiência do Mercado Pago no checkout da sua loja.';
$_MODULE['<{mercadopago}prestashop>standardsettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Ativo';
$_MODULE['<{mercadopago}prestashop>standardsettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Inativo';
$_MODULE['<{mercadopago}prestashop>standardsettings_0da8d9a75492046bea7f314521e07cae'] =
'Meios de pagamento';
$_MODULE['<{mercadopago}prestashop>standardsettings_dd2360b0896865677612fc496a384b2c'] =
' Selecione os meios de pagamento disponíveis em sua loja.';
$_MODULE['<{mercadopago}prestashop>standardsettings_011901666e08f84f38252b5321a7d4de'] =
'Habilite os meios de pagamento disponíveis para seus clientes.';
$_MODULE['<{mercadopago}prestashop>standardsettings_4ad84b90f75b593109969f6a67c0e589'] =
'Máximo de parcelas';
$_MODULE['<{mercadopago}prestashop>standardsettings_0e6481ebfe97897129692fc56936e471'] =
'Qual é o número máximo de vezes que seu cliente pode parcelar a compra? ';
$_MODULE['<{mercadopago}prestashop>standardsettings_5ef05891c0ce9ae545044e6d83e0966d'] =
'Voltar à loja.';
$_MODULE['<{mercadopago}prestashop>standardsettings_9bf51651de5441f6628f68d3859a857e'] =
'Você quer que seu cliente volte';
$_MODULE['<{mercadopago}prestashop>standardsettings_5c37fb51921ed01de76b54887c7bad59'] =
' à loja após finalizar a compra? ';
$_MODULE['<{mercadopago}prestashop>standardsettings_7f6733fc4902833edb6f6d1a89fb4acc'] =
'Modal checkout';
$_MODULE['<{mercadopago}prestashop>standardsettings_833a9c46c3664a83053f319489b4c238'] =
'Seus clientes vão acessar o formulário de pagamentos do Mercado Pago ';
$_MODULE['<{mercadopago}prestashop>standardsettings_6a02c0cb3d450c1e23157b4ef4155a50'] =
'sem sair da sua loja. Se desativar isso, ';
$_MODULE['<{mercadopago}prestashop>standardsettings_ae47f9266c75b0b9cf904ce182f9b510'] =
'eles serão redirecionados a outra página.';
$_MODULE['<{mercadopago}prestashop>standardsettings_deb43872e3df204974c85e5b07ad8576'] =
'Modo binário';
$_MODULE['<{mercadopago}prestashop>standardsettings_65073593c74f39e8b77174346432937e'] =
'Aprove ou recuse pagamentos na hora e de forma automática, ';
$_MODULE['<{mercadopago}prestashop>standardsettings_cef6266789eeb18008a67056a56d680c'] =
'sem status pendentes ou em revisão. Você quer que o ativemos?';
$_MODULE['<{mercadopago}prestashop>standardsettings_14e34536b7eea32e8a7e021bea1b9b91'] =
'Ativá-lo pode afetar a prevenção de fraude. ';
$_MODULE['<{mercadopago}prestashop>standardsettings_e7369d7d7500eb4804b08192ab2b1444'] =
'Deixe-o inativo para que possamos ';
$_MODULE['<{mercadopago}prestashop>standardsettings_f18f9cbe68138db2d541dd171101fb35'] =
'cuidar dos seus recebimentos.';
$_MODULE['<{mercadopago}prestashop>standardsettings_e158df26c6c5fa5329868a48ab2e54ee'] =
'horas sem atividade';
$_MODULE['<{mercadopago}prestashop>standardsettings_f4baa4850222eacc72d4f217fd03e252'] =
'Cancela as preferências de pagamento após';
$_MODULE['<{mercadopago}prestashop>standardsettings_941254e31637b81ac1008e6eb1861c93'] =
'Durante este tempo, vamos salvar as preferências de pagamento ';
$_MODULE['<{mercadopago}prestashop>standardsettings_4476880111ab525b0ef3cfe9173c40ba'] =
'para não ter que pedir os dados do seu cliente novamente. ';
$_MODULE['<{mercadopago}prestashop>standardsettings_42b26ebeb795fcdfdd3d59e3f301970d'] =
'Depois disso, eles serão apagados automaticamente.';
$_MODULE['<{mercadopago}prestashop>ratingsettings_5ecdf7c8fed5fa55b341b963ae70790f'] =
'Obrigado por nos avaliar!';
$_MODULE['<{mercadopago}prestashop>credentialssettings_2daf1cb573c2c61422faf64610cf9402'] =
'Credenciais';
$_MODULE['<{mercadopago}prestashop>credentialssettings_756d97bb256b8580d4d71ee0c547804e'] =
'Produção';
$_MODULE['<{mercadopago}prestashop>credentialssettings_ebc4608a47aa08cb533d928e0259f1df'] =
'Escolha \"SIM\" para começar a receber pagamentos on-line. ';
$_MODULE['<{mercadopago}prestashop>credentialssettings_6087b8439a7036bff644affc8784da4b'] =
'Mude para NÃO para experimentar ';
$_MODULE['<{mercadopago}prestashop>credentialssettings_3bc591c82367247890499e4b021a933e'] =
'loja antes de vender.';
$_MODULE['<{mercadopago}prestashop>credentialssettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Desativar';
$_MODULE['<{mercadopago}prestashop>credentialssettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Ativar';
$_MODULE['<{mercadopago}prestashop>credentialssettings_cd00f38c17c8d33b4ee0141caed3c806'] =
'Adicionar credenciais';
$_MODULE['<{mercadopago}prestashop>credentialssettings_22cea83454a1f571a8935118c4d423f6'] =
'Buscar minhas credenciais';
$_MODULE['<{mercadopago}prestashop>credentialssettings_37c5b6e7c4291021b6100a6754ae7ffe'] =
'Public Key';
$_MODULE['<{mercadopago}prestashop>credentialssettings_5bc7ab301074148dc708229c5ad54fc6'] =
'Access token';
$_MODULE['<{mercadopago}prestashop>credentialssettings_f9465576c2b33512983a54a95bad3210'] =
'Configurações salvas com sucesso. Agora você pode configurar o módulo.';
$_MODULE['<{mercadopago}prestashop>customsettings_263485bdc392a068c22db476bfb5d0f2'] =
'Configuração básica';
$_MODULE['<{mercadopago}prestashop>customsettings_49c557074b8d2bdb3ad51b3e0a7de714'] =
'Ativar checkout';
$_MODULE['<{mercadopago}prestashop>customsettings_d8bf0bd06048ac8cb87266046772cd15'] =
'Ative a experiência do Mercado Pago no checkout da sua loja.';
$_MODULE['<{mercadopago}prestashop>customsettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Ativar';
$_MODULE['<{mercadopago}prestashop>customsettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Desativar';
$_MODULE['<{mercadopago}prestashop>customsettings_deb43872e3df204974c85e5b07ad8576'] =
'Modo binário';
$_MODULE['<{mercadopago}prestashop>customsettings_880bb5685c2e7ef3c65fe0aad31a4dae'] =
'Aprove ou recuse pagamentos na hora e de forma automática, ';
$_MODULE['<{mercadopago}prestashop>customsettings_4c0985e3f8194a2415269103fa9a104d'] =
'sem status pendentes ou em revisão. Você quer que o ativemos?';
$_MODULE['<{mercadopago}prestashop>customsettings_679555bbde4dbc004d33b03a55d4a764'] =
'Ativá-lo pode afetar a prevenção de fraude. ';
$_MODULE['<{mercadopago}prestashop>customsettings_237779dcb8689068ce4d9abdad8c6ce5'] =
'Deixe-o inativo para que possamos cuidar';
$_MODULE['<{mercadopago}prestashop>customsettings_1a9640e57cd90969114812b5bf0c27ef'] =
' cuidar dos seus recebimentos.';
$_MODULE['<{mercadopago}prestashop>customsettings_5143ec2136ffd545e7aafcc9c0ce50f5'] =
'Desconto por compra';
$_MODULE['<{mercadopago}prestashop>customsettings_f2a22ca66322e56b52de81d06834c1e4'] =
'Ofereça um desconto especial para motivar seus ';
$_MODULE['<{mercadopago}prestashop>customsettings_474aceb7275c706995d816dc90bdf45d'] =
'clientes a fazerem a compra com Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_c2adc2174b4cd2fd168bc5de3f1d1c48'] =
'Não é possível remover ';
$_MODULE['<{mercadopago}prestashop>ticketsettings_87fb0447a4e4615a6c2f40ec2154fc1c'] =
'todos os meios de pagamento do Ticket Checkout.';
$_MODULE['<{mercadopago}prestashop>storesettings_80a11d2a54a677f6fadd9c041c0d6b98'] =
'Informações sobre sua loja';
$_MODULE['<{mercadopago}prestashop>storesettings_49ee3087348e8d44e1feda1917443987'] =
'Nome';
$_MODULE['<{mercadopago}prestashop>storesettings_9f122d1b74cc2730551f41a39f024633'] =
'Este nome estará na fatura que criamos para o seu cliente.';
$_MODULE['<{mercadopago}prestashop>storesettings_3adbdb3ac060038aa0e6e6c138ef9873'] =
' Categoria';
$_MODULE['<{mercadopago}prestashop>storesettings_4182e847f507c9ea3adc3c5aa742ba66'] =
'A qual categoria os seus produtos pertencem? ';
$_MODULE['<{mercadopago}prestashop>storesettings_a125e14c06e3cdcf245efc8fbf61d6d7'] =
'Selecione a que melhor os caracteriza ';
$_MODULE['<{mercadopago}prestashop>storesettings_8f69960af1e12c180f1a274210f219ad'] =
'(selecione outro se o seu produto for muito específico).';
$_MODULE['<{mercadopago}prestashop>storesettings_67cb4db65a7c5f0878b2d5aa20db71ba'] =
'Integrator ID';
$_MODULE['<{mercadopago}prestashop>storesettings_67a10b694ba920e2ad489d7637b78db4'] =
'Com este número, identificamos todas as suas transações  ';
$_MODULE['<{mercadopago}prestashop>storesettings_4a792eeaee7dfa3703cfb05e4940ad1b'] =
'e sabemos quantas vendas processamos com a sua conta.';
$_MODULE['<{mercadopago}prestashop>localizationsettings_369686331c93d55e587441143ccdf427'] =
'Localização';
$_MODULE['<{mercadopago}prestashop>localizationsettings_f64be5eef68442a8f50cf535b92ad3e4'] =
'País:';
$_MODULE['<{mercadopago}prestashop>localizationsettings_bdaea8d8b9968a9c9ec57e2ebf37d9f8'] =
' Selecione o país onde sua conta do Mercado Pago opera.';
$_MODULE['<{mercadopago}prestashop>localizationsettings_f9465576c2b33512983a54a95bad3210'] =
' Configurações salvas com sucesso. Agora você pode configurar o módulo.';
$_MODULE['<{mercadopago}prestashop>localizationsettings_8b144ffc87beff564884b1c190275539'] =
'Selecione o  país';
$_MODULE['<{mercadopago}prestashop>localizationsettings_3536be57ce0713954e454ae6c53ec023'] =
'Argentina';
$_MODULE['<{mercadopago}prestashop>localizationsettings_42537f0fb56e31e20ab9c2305752087d'] =
'Brasil';
$_MODULE['<{mercadopago}prestashop>localizationsettings_2e6507f70a9cc26fb50f5fd82a83c7ef'] =
'Chile';
$_MODULE['<{mercadopago}prestashop>localizationsettings_ef3388cc5659bccb742fb8af762f1bfd'] =
'Colômbia';
$_MODULE['<{mercadopago}prestashop>localizationsettings_8dbb07a18d46f63d8b3c8994d5ccc351'] =
'México';
$_MODULE['<{mercadopago}prestashop>localizationsettings_84c8fa2341f7d052a1ee3a36ff043798'] =
'Peru';
$_MODULE['<{mercadopago}prestashop>localizationsettings_75497a22409db78dcc52c291e078bc10'] =
'Uruguai';
$_MODULE['<{mercadopago}prestashop>localizationsettings_e95294b730f61c8175550ec244bfcb50'] =
'Venezuela';
$_MODULE['<{mercadopago}prestashop>ticketsettings_263485bdc392a068c22db476bfb5d0f2'] =
'Configuração básica';
$_MODULE['<{mercadopago}prestashop>ticketsettings_7d7ad4775c720af6567f212e5e4ec012'] =
'Ativar checkout para pagamentos presenciais';
$_MODULE['<{mercadopago}prestashop>ticketsettings_c464d6c07376bc896eaef0a39673154a'] =
'Ative a experiência do Mercado Pago no checkout da sua loja.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Ativar';
$_MODULE['<{mercadopago}prestashop>ticketsettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Desativar';
$_MODULE['<{mercadopago}prestashop>ticketsettings_0da8d9a75492046bea7f314521e07cae'] =
'Meios de pagamento presenciais';
$_MODULE['<{mercadopago}prestashop>ticketsettings_958cb40bf8532bac958dd71b30867ee4'] =
'Habilite os meios de pagamento disponíveis para seus clientes.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_44fdec47036f482b68b748f9d786801b'] =
'dias';
$_MODULE['<{mercadopago}prestashop>ticketsettings_1787da92a63da5bfdf8b2aa3e7a8d54e'] =
'Vencimento do pagamento';
$_MODULE['<{mercadopago}prestashop>ticketsettings_67b09091d73c254778332c4ba38c6011'] =
'Em quantos dias os pagamentos via boleto e em lotéricas vencerão.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_5143ec2136ffd545e7aafcc9c0ce50f5'] =
'Desconto por compra';
$_MODULE['<{mercadopago}prestashop>ticketsettings_f2a22ca66322e56b52de81d06834c1e4'] =
'Ofereça um desconto especial para motivar seus ';
$_MODULE['<{mercadopago}prestashop>ticketsettings_474aceb7275c706995d816dc90bdf45d'] =
'clientes a fazerem a compra com Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>abstractpreference_e2b7dec8fa4b498156dfee6e4c84b156'] =
'Este meio de pagamento não está disponível.';
$_MODULE['<{mercadopago}prestashop>template_1_9ab558f4124ae3f7f96ddb62799c5ae0'] =
'Crie a melhor experiência de pagamento para seus clientes';
$_MODULE['<{mercadopago}prestashop>template_1_2e2d4be43cfc9cf97f58cc59b19fe5a5'] =
'Siga estas etapas e leve sua conversão às nuvens:';
$_MODULE['<{mercadopago}prestashop>template_1_3972296bf88ad8b9df45219704cbc499'] =
'Obtenha suas';
$_MODULE['<{mercadopago}prestashop>template_1_d3ed68f7315b7e72b8d886b2278fcac3'] =
'credenciais';
$_MODULE['<{mercadopago}prestashop>template_1_a74702c3f87efa59784d648c68cbe7ea'] =
'na sua conta do Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_1_afbb92a0d1285fbd49350014669046f3'] =
'Homologue sua conta.';
$_MODULE['<{mercadopago}prestashop>template_1_6b4fb1dba01491995d2222e8e6f59dd0'] =
'Selecione os';
$_MODULE['<{mercadopago}prestashop>template_1_b8d8952ddd5e6db1936bd51b88edc760'] =
'meios de pagamento';
$_MODULE['<{mercadopago}prestashop>template_1_b52ba38c3bc63fbc7f2c36b472455143'] =
'disponíveis na sua loja.';
$_MODULE['<{mercadopago}prestashop>template_1_c6bb78598105e349729d9ebb019d739b'] =
'Deixe o';
$_MODULE['<{mercadopago}prestashop>template_1_2652eec977dcb2a5aea85f5bec235b05'] =
'Sandbox';
$_MODULE['<{mercadopago}prestashop>template_1_3dd7c03abf4b169d72637025fad108aa'] =
'para testar compras na sua loja.';
$_MODULE['<{mercadopago}prestashop>template_1_05b0d76c904472532b5ab0ec235a16b8'] =
'Desative-o se estiver pronto para receber pagamentos.';
$_MODULE['<{mercadopago}prestashop>template_1_b3d228eb96c4d15caabb6507e9e8acba'] =
'As credenciais são as senhas que informamos para que você integre de forma rápida e segura.';
$_MODULE['<{mercadopago}prestashop>template_1_9e71c2e834abb091bae5fab9bba7754a'] =
'Homologue sua conta para ir a Produção e receber pagamentos na sua loja.';
$_MODULE['<{mercadopago}prestashop>template_1_5a1313cc21947818bfdbd9f5e7a3b8b6'] =
'Você não precisa de conhecimentos de programação ou design para ativar o Mercado Pago na sua loja.';
$_MODULE['<{mercadopago}prestashop>template_1_de6b2e0f77335f7f48c28e2df309a753'] =
'Checkout do Mercado Pago';
$_MODULE['<{mercadopago}prestashop>template_1_e05dacc06bcd12a1dbc7340983ac5a03'] =
'Checkout de pagamentos com cartão';
$_MODULE['<{mercadopago}prestashop>template_1_055e6bd0167d88d8c87ed8e4db5b7108'] =
'Ticket Checkout';
$_MODULE['<{mercadopago}prestashop>template_1_34e8683b67ce338dc5d22bd0c1958458'] =
'Teste sua loja';
$_MODULE['<{mercadopago}prestashop>template_1_295a38ad46665a436f94cc11ba5033ff'] =
'Tudo configurado? Veja sua loja no modo Sandbox';
$_MODULE['<{mercadopago}prestashop>template_1_a2d1c5986e732ef32d7d7ec6e1c02ffb'] =
'Visita sua loja como se fosse um dos seus melhores clientes. Confira se está tudo em ordem para impressionar os clientes e aumentar suas vendas.';
$_MODULE['<{mercadopago}prestashop>template_1_0611191252088be4f499b8674236f3cb'] =
'Quero testar minhas vendas';
$_MODULE['<{mercadopago}prestashop>template_1_35e1af020b043e72d20163fbb8a908c2'] =
'Começar a vender';
$_MODULE['<{mercadopago}prestashop>template_1_3aafca1b84d90601b6a86157a6cfc7fa'] =
'Você já está em produção!';
$_MODULE['<{mercadopago}prestashop>template_1_a331433d3b422894749a70f4cf957c68'] =
'Tudo pronto para a decolagem das suas vendas. Agora, traga seus clientes';
$_MODULE['<{mercadopago}prestashop>template_1_8bf0f4e736bdf1982f90e3b27a4277ab'] =
'para oferecer a eles a melhor experiência de compra on-line com o Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_1_a36f1b340c78e8d39d215ba65f37b3b4'] =
'Visitar minha loja';
$_MODULE['<{mercadopago}prestashop>template_1_6eca86a8671f52bc8d9a73d1c677922c'] =
'Há algum problema? ';
$_MODULE['<{mercadopago}prestashop>template_1_0e6444c61d2aebf9a778787ee9322559'] =
'Fale com a nossa equipe de suporte.';
$_MODULE['<{mercadopago}prestashop>template_1_0b50f5dd5293d9a770a6f6370fc72d0c'] =
'Ajude-nos a melhorar';
$_MODULE['<{mercadopago}prestashop>template_1_776ad719457341aa0913807e47260a8e'] =
'Ajude-nos a melhorar';
$_MODULE['<{mercadopago}prestashop>template_1_f27513a2f23d3c32b5dd948902ba470e'] =
'De 1 a 10, qual é a probabilidade de você nos recomendar a um amigo?';
$_MODULE['<{mercadopago}prestashop>template_1_6932676695a18a04d771736f169c31dd'] =
'Nada provável';
$_MODULE['<{mercadopago}prestashop>template_1_389344a1748d5b72b78ffe1ded4df6b4'] =
'Pouco provável';
$_MODULE['<{mercadopago}prestashop>template_1_97aeaf0de4598b006e47a1384a2e3646'] =
'Muito provável';
$_MODULE['<{mercadopago}prestashop>template_1_9fe6b590f9b933c4fc5acd9be20fb52e'] =
'Comentários ou sugestões? Este é o espaço ideal:';
$_MODULE['<{mercadopago}prestashop>template_1_70258a400d27560f7e24fca8eb24ee48'] =
'Deixe seu comentário';
$_MODULE['<{mercadopago}prestashop>template_1_d3d2e617335f08df83599665eef8a418'] =
'Fechar';
$_MODULE['<{mercadopago}prestashop>template_1_94966d90747b97d1f0f206c98a8b1ac3'] =
'Enviar';
$_MODULE['<{mercadopago}prestashop>configure_ebfdf406440ec86efe63337c2190ed88'] =
'Configurar Mercado Pago ';
$_MODULE['<{mercadopago}prestashop>configure_b981586a7501c83c66f984e211a8edc1'] =
'Sobre o Mercado Pago';
$_MODULE['<{mercadopago}prestashop>configure_dbc0cd962f974e382f7dc1e5faac838a'] =
'Versão atual:';
$_MODULE['<{mercadopago}prestashop>configure_37601413631163f290129f5fe802a7ae'] =
'Em qual país a sua conta do Mercado Pago opera?';
$_MODULE['<{mercadopago}prestashop>configure_167ba6d3d5b002a68362baaee36759c5'] =
'Ative suas credenciais de acordo com o que você quer fazer.';
$_MODULE['<{mercadopago}prestashop>configure_03a36f89aad8dd8286bc5fe6692cbbeb'] =
'Modo Teste';
$_MODULE['<{mercadopago}prestashop>configure_705f67afe64f4bc771a4bf0873898ad2'] =
'Por padrão, deixamos o ambiente de teste (Sandbox) ativo para você testar antes de começar a vender.';
$_MODULE['<{mercadopago}prestashop>configure_53b96c3aa535ed88afe3edfaaa3e570d'] =
'Modo Produção';
$_MODULE['<{mercadopago}prestashop>configure_230755e96a95b2645824724bcb3edd36'] =
'Tudo em ordem? Desative o Sandbox e abra o caminho para suas vendas on-line.';
$_MODULE['<{mercadopago}prestashop>configure_45efbe3093b6d35ec6e43e0eb07c1503'] =
'Credenciais de Teste';
$_MODULE['<{mercadopago}prestashop>configure_bd169ac4f12a3abfa75ea23058c2af55'] =
'Com esta chave você poderá fazer aos testes que quiser';
$_MODULE['<{mercadopago}prestashop>configure_1cdec16cf8a4a897737cd056504193bf'] =
'Credenciais de Produção';
$_MODULE['<{mercadopago}prestashop>configure_9b397137fdf77852e7eafa8da2221520'] =
'Com esta chave você poderá receber pagamentos reais dos seus clientes.';
$_MODULE['<{mercadopago}prestashop>configure_f4a4738ceaec1830e180c710aa5c0989'] =
'Homologue sua conta, isso levará somente alguns minutos';
$_MODULE['<{mercadopago}prestashop>configure_ef11de888be253b9e3556a7f64703596'] =
'Conclua este processo para proteger os dados';
$_MODULE['<{mercadopago}prestashop>configure_5dc8a3f47c7e2cd0b5a615a568c381b6'] =
'dos seus clientes e garantir a adequação às normas e ';
$_MODULE['<{mercadopago}prestashop>configure_5bfd14259acc34028aef59bae1296993'] =
'provisões legais de cada país.';
$_MODULE['<{mercadopago}prestashop>configure_2401b8d430cf1acf0427302580d9478d'] =
'Homologar minha conta';
$_MODULE['<{mercadopago}prestashop>configure_80a11d2a54a677f6fadd9c041c0d6b98'] =
'Informações sobre sua loja';
$_MODULE['<{mercadopago}prestashop>configure_024eb7a83d8dec5f53ef18d2cc24c42a'] =
'Digite os dados da sua empresa no módulo:';
$_MODULE['<{mercadopago}prestashop>configure_cdd96fbd5af791ea36d0eab3b5c0cbcc'] =
'Você é um parceiro do Mercado Pago?';
$_MODULE['<{mercadopago}prestashop>configure_418ea206bf7c7ec9d85e436517446d90'] =
'Ofereça todos os meios de pagamento. ';
$_MODULE['<{mercadopago}prestashop>configure_a823edeec9a893e526be44211b11dd21'] =
'Experiência de pagamento no site do Mercado Pago. ';
$_MODULE['<{mercadopago}prestashop>configure_ba409932f82a5dbbc411b83fe3e8adb7'] =
'Seus clientes podem pagar como visitantes ou acessando a conta do Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>configure_edcc027aee641dec9c6e6cfa70aede7d'] =
'Seu cliente paga de forma rápida, fácil e segura com estas opções:';
$_MODULE['<{mercadopago}prestashop>configure_0da8d9a75492046bea7f314521e07cae'] =
'Selecione cartões';
$_MODULE['<{mercadopago}prestashop>configure_24e9fd6116bb8c7c0f060273672067e2'] =
'Selecione pagamentos presenciais';
$_MODULE['<{mercadopago}prestashop>configure_c70ec5b31b31ecef0efd3ea40e33909f'] =
'Configuração Avançada';
$_MODULE['<{mercadopago}prestashop>configure_18b934da2943766913dc95ae10cd11d9'] =
'Ative outras ferramentas do nosso módulo, prontas para uso.';
$_MODULE['<{mercadopago}prestashop>configure_1bc20b46625d14ce9a7587faf7af4171'] =
'Ofereça pagamentos com cartão de crédito. ';
$_MODULE['<{mercadopago}prestashop>configure_7e3c0f9991ae9abe60ee5e022ae42159'] =
'Experiência de pagamento na sua loja.';
$_MODULE['<{mercadopago}prestashop>configure_6e7cc3c1db795bffb2de3a237442e047'] =
'Seus clientes pagam como visitantes sem sair da sua loja.';
$_MODULE['<{mercadopago}prestashop>configure_2cf04dc84eb55a15d6557f1f30eb63ad'] =
'Ofereça pagamentos em dinheiro.';
$_MODULE['<{mercadopago}prestashop>configure_9816529bd797ea2cf8c0dfe7b13b9dd2'] =
'Seu cliente paga de forma rápida, fácil e segura com estas opções:';
$_MODULE['<{mercadopago}prestashop>template_2_d6cf1a3115755104888673a6b9e3acf6'] =
'Aumente suas vendas on-line';
$_MODULE['<{mercadopago}prestashop>template_2_0275de4d9b97b8b6c73adf434500771c'] =
'Ofereça a melhor experiência';
$_MODULE['<{mercadopago}prestashop>template_2_a04c73627fe84661558c0cca42df4dcf'] =
'de pagamento para os seus clientes. ';
$_MODULE['<{mercadopago}prestashop>template_2_984641c8c6d6a5ccfe1c7b70902efbed'] =
'Configure o Mercado Pago';
$_MODULE['<{mercadopago}prestashop>template_2_9a59fbee87ac663ed34c1ad8552cdd28'] =
'Mostra promoções e ';
$_MODULE['<{mercadopago}prestashop>template_2_ba78227f84b4f2f3b63369ff466fde28'] =
'venda parcelado com a melhor';
$_MODULE['<{mercadopago}prestashop>template_2_2f3dcea44606632f4c34ddde2bb2cda7'] =
' opção de financiamento possível. ';
$_MODULE['<{mercadopago}prestashop>template_2_2222376e726e3e241627eae36bc3dae5'] =
'Nós cobraremos uma comissão por cada venda que você receber.';
$_MODULE['<{mercadopago}prestashop>template_2_34497fd2ef216c6ae8702b540a345a6f'] =
'Quais são os benefícios de ';
$_MODULE['<{mercadopago}prestashop>template_2_07156bcf3b3864f373f3e3f78eac9113'] =
'receber com o Mercado Pago na minha loja? ';
$_MODULE['<{mercadopago}prestashop>template_2_909e19c722cf2bd12064190b5bd146c6'] =
'Venda sem limites, sem precisar de design nem de programação. ';
$_MODULE['<{mercadopago}prestashop>template_2_8ef62d890ae454308fa0cb6c12125437'] =
'Maximize sua conversão com';
$_MODULE['<{mercadopago}prestashop>template_2_1dbee053eebd52c8c4d8abcdcca52a04'] =
'a melhor experiência de pagamento.';
$_MODULE['<{mercadopago}prestashop>template_2_d6589ce85c5eef9eeafe406a11cf6713'] =
'Você tem ferramentas prontas para usar e ';
$_MODULE['<{mercadopago}prestashop>template_2_399c1f7ea114e0a5d6c6a4e66783e4db'] =
'especialistas preparados para te ajudar.';
$_MODULE['<{mercadopago}prestashop>template_2_8254e152eb98ce090be059e2d40a2bc7'] =
'Como recebo os pagamentos?';
$_MODULE['<{mercadopago}prestashop>template_2_7998c642e7e2568b4d748a5923d497aa'] =
'Seus clientes pagam com o meio de pagamento que preferem.';
$_MODULE['<{mercadopago}prestashop>template_2_2c1d1e4f152962e02d1151957f33c8bf'] =
'O valor é creditado';
$_MODULE['<{mercadopago}prestashop>template_2_a59d3d544ff6983c0877ea5caa16a2b0'] =
'na sua conta do Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_2_e9299886340fc65e2c7e42bb64ebb0e1'] =
'Quando disponível,';
$_MODULE['<{mercadopago}prestashop>template_2_22c9f9da706bfe8c6735a88b486970c0'] =
' você pode retirá-lo para sua conta bancária sem custo adicional.';
$_MODULE['<{mercadopago}prestashop>template_2_aa94393365aa5eae33a504e61457d447'] =
'O que eu posso fazer com o';
$_MODULE['<{mercadopago}prestashop>template_2_987d06b272f6a80ae2fad5f18c1b2524'] =
'Mercado Pago na minha loja? ';
$_MODULE['<{mercadopago}prestashop>template_2_f50c11299b7ea4211969944cda8ece2f'] =
'Compras em um clique:';
$_MODULE['<{mercadopago}prestashop>template_2_e99a5c379a69fa1eb41aef11c97f8a62'] =
'lembramos dos dados dos seus usuários.';
$_MODULE['<{mercadopago}prestashop>template_2_6b8816b3ebd85760ccbe3535518f5628'] =
'Pagamento como convidado:';
$_MODULE['<{mercadopago}prestashop>template_2_d3f293f60d44a9099d36b93bd1c71ee3'] =
'seus clientes não precisam abrir uma conta no Mercado Pago';
$_MODULE['<{mercadopago}prestashop>template_2_d2f7e9781e7c0d7d50d8a5247dff453c'] =
'Devolução de pagamentos e cancelamento';
$_MODULE['<{mercadopago}prestashop>template_2_388ac0bf13986abefe449b83a0cbda0e'] =
'de pagamentos pendentes.';
$_MODULE['<{mercadopago}prestashop>template_2_89f716cae37270d25f9c4d1664eb10fc'] =
'Crescer só depende de você.';
$_MODULE['<{mercadopago}prestashop>template_2_c8e43776845c4374c26c305c36f6460f'] =
'Ofereça uma experiência de';
$_MODULE['<{mercadopago}prestashop>template_2_105ceb4f9d70cd97123fdb2bfceb8a2a'] =
'pagamento única para os seus clientes. ';
$_MODULE['<{mercadopago}prestashop>template_2_bb0a503f6022dd9ad15e450f25480f8b'] =
'Somos parceiros oficiais de Prestashop';
$_MODULE['<{mercadopago}prestashop>template_2_f8e3823fce704473f01e4781d07bf917'] =
'Programa de proteção de vendedores.';
$_MODULE['<{mercadopago}prestashop>failure_55d37c0a3c1b32de6e3f9ceb1f8c0a4a'] =
'Ops! Ocorreu um erro no seu pagamento, tente novamente ...';
$_MODULE['<{mercadopago}prestashop>custom_bbfe522e4f1486075b15c60e603fee6d'] =
'Quero pagar com cartão de crédito';
$_MODULE['<{mercadopago}prestashop>custom_b2fd5a4f417785d2c8d5a3674a1b3e83'] =
'Com quais cartões posso pagar?';
$_MODULE['<{mercadopago}prestashop>custom_e7f9e382dc50889098cbe56f2554c77b'] =
'Cartão de crédito';
$_MODULE['<{mercadopago}prestashop>custom_87aed576797f8992ddc7a8c629fb7035'] =
'Cartão de débito';
$_MODULE['<{mercadopago}prestashop>custom_e4179c3a6980bed5071fe92c929e6157'] =
'Informe os dados do seu cartão';
$_MODULE['<{mercadopago}prestashop>custom_a44217022190f5734b2f72ba1e4f8a79'] =
'Número do cartão';
$_MODULE['<{mercadopago}prestashop>custom_00cc96b2cd5db9825852af3700813e4e'] =
'Número do cartão inválido';
$_MODULE['<{mercadopago}prestashop>custom_bab78a96a00725b7efa6f34f452d17b9'] =
'Titular do cartão';
$_MODULE['<{mercadopago}prestashop>custom_ae35ed084114b30399338fa515188bcb'] =
'Código de segurança inválido';
$_MODULE['<{mercadopago}prestashop>custom_8c1279db4db86553e4b9682f78cf500e'] =
'Data de vencimento';
$_MODULE['<{mercadopago}prestashop>custom_22d248eda08203b9ebb7b84ca22635cb'] =
'Data de validade do cartão inválida';
$_MODULE['<{mercadopago}prestashop>custom_792bb28aea0e109daf741be7eb18ec87'] =
'Código de segurança';
$_MODULE['<{mercadopago}prestashop>custom_60a104dc50579d60cbc90158fada1dcf'] =
'CVV';
$_MODULE['<{mercadopago}prestashop>custom_b905fb66f717edccb30cb861bc1f20f0'] =
'Últimos 3 números do verso';
$_MODULE['<{mercadopago}prestashop>custom_f8809653e0184b71678421dc963074c7'] =
'Em quantas parcelas você quer pagar';
$_MODULE['<{mercadopago}prestashop>custom_16bfdf30b1a694ab3bf3da553a4dff03'] =
'Banco emissor';
$_MODULE['<{mercadopago}prestashop>custom_2aeaeb22ad892fd719ccde8e3d55617d'] =
'Informe seu número de documento';
$_MODULE['<{mercadopago}prestashop>custom_a1fa27779242b4902f7ae3bdd5c6d508'] =
'Tipo';
$_MODULE['<{mercadopago}prestashop>custom_14c44ffb79e2c416100024bd491b48b9'] =
'Número de documento';
$_MODULE['<{mercadopago}prestashop>custom_e5ef874bb07f7b149fd67a72e713d624'] =
'Somente número';
$_MODULE['<{mercadopago}prestashop>custom_9abfb506bebd1e72069f0be0014986dc'] =
'Número de documento inválido';
$_MODULE['<{mercadopago}prestashop>custom_ab8a2170eb587c1022ad4ee33eb99e7f'] =
'Campo obrigatório';
$_MODULE['<{mercadopago}prestashop>custom_377e99e7404b414341a9621f7fb3f906'] =
'Finalizar pedido';
$_MODULE['<{mercadopago}prestashop>custom_961f2247a2070bedff9f9cd8d64e2650'] =
'Escolher';
$_MODULE['<{mercadopago}prestashop>standard_e7f9e382dc50889098cbe56f2554c77b'] =
'Cartão de crédito';
$_MODULE['<{mercadopago}prestashop>standard_26f5a22330a8d5d32c87e6a4c7f3de95'] =
'Até';
$_MODULE['<{mercadopago}prestashop>standard_7d41ca7af6f495d8e3432f8a4544f253'] =
'parcelas';
$_MODULE['<{mercadopago}prestashop>standard_87aed576797f8992ddc7a8c629fb7035'] =
'Cartão de débito';
$_MODULE['<{mercadopago}prestashop>standard_95428f32e5c696cf71baccb776bc5c15'] =
'Transferência bancária';
$_MODULE['<{mercadopago}prestashop>standard_a4742458d37df9c6a26f9c99ed8bcb3f'] =
'Levamos você ao nosso site para concluir o pagamento';
$_MODULE['<{mercadopago}prestashop>ticket_return_24a4e89cbe1fdf5548035b98660db505'] =
'Obrigado por sua compra! Estamos aguardando o pagamento.';
$_MODULE['<{mercadopago}prestashop>ticket_return_21d104a54fc71a19a325c7305327f1d2'] =
'Em processamento';
$_MODULE['<{mercadopago}prestashop>ticket_return_051b4fc3b5b94694296b17af2f969dfc'] =
'Imprimir';
$_MODULE['<{mercadopago}prestashop>custom_dc4554b3840d99f5489a30a49f9477b4'] =
'Promoções vigentes';
$_MODULE['<{mercadopago}prestashop>ticket_2aeaeb22ad892fd719ccde8e3d55617d'] =
'Informe seu número de documento';
$_MODULE['<{mercadopago}prestashop>ticket_a1fa27779242b4902f7ae3bdd5c6d508'] =
'Tipo';
$_MODULE['<{mercadopago}prestashop>ticket_3ba0f40775d6d6ace27ef929f5be3cdf'] =
'CI';
$_MODULE['<{mercadopago}prestashop>ticket_14c44ffb79e2c416100024bd491b48b9'] =
'Número de documento';
$_MODULE['<{mercadopago}prestashop>ticket_2dd4472245a696bc0b4b944db2a8b519'] =
'Pessoa física';
$_MODULE['<{mercadopago}prestashop>ticket_5a4471420aa5026337a78145a7f97b63'] =
'Pessoa jurídica';
$_MODULE['<{mercadopago}prestashop>ticket_d4150c6bd6a42bda6fc0bcc118cafd41'] =
'Nome';
$_MODULE['<{mercadopago}prestashop>ticket_4e1d2b56da5ef5d0c57afc363cb790d8'] =
'Razão social';
$_MODULE['<{mercadopago}prestashop>ticket_165613bac50ccc224e149a310147a944'] =
'Você deve informar seu nome';
$_MODULE['<{mercadopago}prestashop>ticket_77587239bf4c54ea493c7033e1dbf636'] =
'Sobrenome';
$_MODULE['<{mercadopago}prestashop>ticket_515003ca1a070566016e4ac6312097da'] =
'Você deve informar o sobrenome';
$_MODULE['<{mercadopago}prestashop>ticket_e3fe6d057f44794ab6098de4ada86d80'] =
'CPF';
$_MODULE['<{mercadopago}prestashop>ticket_c64553750fa9a18283d45c328cdf7411'] =
'CNPJ';
$_MODULE['<{mercadopago}prestashop>ticket_4486ead55880d17a0d1fec8e90dd1783'] =
'O documento deve ser válido';
$_MODULE['<{mercadopago}prestashop>ticket_dd7bf230fde8d4836917806aff6a6b27'] =
'Endereço';
$_MODULE['<{mercadopago}prestashop>ticket_e38b9b2c9db79347219f907478d3181d'] =
'Você deve informar o endereço';
$_MODULE['<{mercadopago}prestashop>ticket_b2ee912b91d69b435159c7c3f6df7f5f'] =
'Número';
$_MODULE['<{mercadopago}prestashop>ticket_21aba1a06a9c8a7375da5f69a8a24025'] =
'Você deve informar o número do endereço';
$_MODULE['<{mercadopago}prestashop>ticket_57d056ed0984166336b7879c2af3657f'] =
'Cidade';
$_MODULE['<{mercadopago}prestashop>ticket_46a2a41cc6e552044816a2d04634545d'] =
'Estado';
$_MODULE['<{mercadopago}prestashop>ticket_383f23791705084d1189869ac40ca9c5'] =
'Selecione o estado';
$_MODULE['<{mercadopago}prestashop>ticket_f8b1b7cee36ca4abc72a9edbbece60dc'] =
'Você deve informar o estado';
$_MODULE['<{mercadopago}prestashop>ticket_25f75488c91cb6c3bab92672e479619f'] =
'CEP';
$_MODULE['<{mercadopago}prestashop>ticket_4c86644753757af0f7b40840ddb76762'] =
'Você deve informar o CEP';
$_MODULE['<{mercadopago}prestashop>ticket_7ed938d13683ef13343362a05226f0e9'] =
'Por favor, preencha todos os campos, são obrigatórios.';
$_MODULE['<{mercadopago}prestashop>ticket_04cf30c71ec29aee2615e8cd526afeef'] =
'Seleccione o meio de pagamento';
$_MODULE['<{mercadopago}prestashop>standard_3e8bd808fa886bce4b3de20f28870f9d'] =
'Quero pagar com Mercado Pago sem custo adicional.';
$_MODULE['<{mercadopago}prestashop>standard_d80b215711d6701ab5dae0b8171f4da3'] =
'Use o método de pagamento de sua preferência.';
$_MODULE['<{mercadopago}prestashop>ticket_5edffb5efe684d534217bad198adeece'] =
'Quero pagar via boleto ou na lotérica ';
$_MODULE['<{mercadopago}prestashop>ticket_49ee3087348e8d44e1feda1917443987'] =
'Nome';
$_MODULE['<{mercadopago}prestashop>ticket_377e99e7404b414341a9621f7fb3f906'] =
'Finalizar pedido';
$_MODULE['<{mercadopago}prestashop>mpapi_052dbe4cbe0fc4c37bbb5c59f70ac2d4'] =
'O meio de pagamento não é válido ou não está disponível.';
$_MODULE['<{mercadopago}prestashop>mpapi_9fdd961e41fdff842c80aea4a875138d'] =
'O valor da transação não pode ser processado pelo Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>mpapi_8a6cb9e19e687968bffd11566895bb00'] =
'Possíveis causas: Moeda não suportada; ';
$_MODULE['<{mercadopago}prestashop>mpapi_81e3267deaa45a720e31c55e53d45d95'] =
'Valores abaixo do mínimo ou acima do máximo permitido.';
$_MODULE['<{mercadopago}prestashop>mpapi_8a0595f24ba7e98096ea2f52d1546605'] =
'Os usuários não são válidos. Possíveis causas: ';
$_MODULE['<{mercadopago}prestashop>mpapi_edf9cda9340f50dce8b4dad690c68341'] =
'o comprador e o vendedor têm a mesma conta no Mercado Pago; ';
$_MODULE['<{mercadopago}prestashop>mpapi_5f65da2a91e569c0f6c8821a8f354cf3'] =
'A transação está envolvendo usuários de produção e teste.';
$_MODULE['<{mercadopago}prestashop>mpapi_c92a089d8ab502e6ff18d8bf1c724833'] =
'Uso não autorizado de credenciais de produção. ';
$_MODULE['<{mercadopago}prestashop>mpapi_ac7495823e9778d3ffc7677ac5d3765a'] =
'Possíveis causas: Pendência de permissão de uso na produção para a credencial do vendedor.';
$_MODULE['<{mercadopago}prestashop>payment_return_3e09b7a997278261b6db524197e20bf8'] =
'Obrigado por sua compra!';
$_MODULE['<{mercadopago}prestashop>payment_return_21d104a54fc71a19a325c7305327f1d2'] =
'Processando...';
$_MODULE['<{mercadopago}prestashop>payment_return_051b4fc3b5b94694296b17af2f969dfc'] =
'Imprimir';
$_MODULE['<{mercadopago}prestashop>payment_return_deb10517653c255364175796ace3553f'] =
'Produto';
$_MODULE['<{mercadopago}prestashop>payment_return_3601146c4e948c32b6424d2c0a7f0118'] =
'Preço';
$_MODULE['<{mercadopago}prestashop>payment_return_03ab340b3f99e03cff9e84314ead38c0'] =
'Qtd';
$_MODULE['<{mercadopago}prestashop>payment_return_2194aaec8cc7086ab0e93f74547e5f53'] =
'Subtotal';
$_MODULE['<{mercadopago}prestashop>payment_return_104d9898c04874d0fbac36e125fa1369'] =
'Desconto';
$_MODULE['<{mercadopago}prestashop>payment_return_ea9cf7e47ff33b2be14e6dd07cbcefc6'] =
'Frete e manuseio';
$_MODULE['<{mercadopago}prestashop>payment_return_3af22b59f4641bc5501998297f9ac70d'] =
'TOTAL';

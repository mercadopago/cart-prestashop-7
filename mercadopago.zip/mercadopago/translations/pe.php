<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mercadopago}prestashop>mercadopago_3ce3662af6cffea8677b4cb92dea4939'] = 'Mercado Pago';
$_MODULE['<{mercadopago}prestashop>mercadopago_b9a2e0f33da43f952a816aa78f78ee2e'] = 'Personaliza la experiencia 
de pago de tus clientes y convierte tu sitio en una tienda online.';
$_MODULE['<{mercadopago}prestashop>mercadopago_0f379daaee21894a7c6453950658fe8b'] = '¿Está seguro de que desea 
desinstalar el módulo?';
$_MODULE['<{mercadopago}prestashop>mercadopago_a88f84d8cb58f8230240e1665058c7ff'] = 'Tienes que habilitar la 
extensión cURL ';
$_MODULE['<{mercadopago}prestashop>mercadopago_d4423ad419d2bf8911d67aae2710b2bf'] = 'en su servidor para instalar 
este módulo.';
$_MODULE['<{mercadopago}prestashop>mercadopago_369686331c93d55e587441143ccdf427'] = 'Localización';
$_MODULE['<{mercadopago}prestashop>mercadopago_63406c9482c644975f227cc93788e8fb'] = 'Elegí tu país';
$_MODULE['<{mercadopago}prestashop>mercadopago_7acec827588348830ccf634fc6d38901'] = 'Selecciona el país en el que 
opera tu cuenta de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>mercadopago_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{mercadopago}prestashop>mercadopago_f9465576c2b33512983a54a95bad3210'] = 'Ajustes guardados con éxito. 
Ahora puedes configurar el módulo.';
$_MODULE['<{mercadopago}prestashop>mercadopago_2488dda96f94d5e5d7f227690ed5fabc'] = 'Homologación';
$_MODULE['<{mercadopago}prestashop>mercadopago_2daf1cb573c2c61422faf64610cf9402'] = 'Credenciales';
$_MODULE['<{mercadopago}prestashop>mercadopago_8eaf9dd80ecfbd6de7c83cf3b707232b'] = 'Modo Sandbox';
$_MODULE['<{mercadopago}prestashop>mercadopago_aafbf9741a9922c19f40e6039dd08a7a'] = 'Escoge “SÍ” para probar tu 
tienda antes de vender. ';
$_MODULE['<{mercadopago}prestashop>mercadopago_810b21a24560a01466c097bcb5041319'] = 'Cambia a “NO” para desactivar 
el modo pruebas ';
$_MODULE['<{mercadopago}prestashop>mercadopago_215b33567e2d1dd229c16d97dcf350eb'] = 'y empezar a recibir cobros 
online.';
$_MODULE['<{mercadopago}prestashop>mercadopago_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activo';
$_MODULE['<{mercadopago}prestashop>mercadopago_3cab03c00dbd11bc3569afa0748013f0'] = 'Inactivo';
$_MODULE['<{mercadopago}prestashop>mercadopago_e79d3a058e8451da65a54fde3a69fb0f'] = 'Cargar credenciales';
$_MODULE['<{mercadopago}prestashop>mercadopago_22cea83454a1f571a8935118c4d423f6'] = 'Buscar mis credenciales';
$_MODULE['<{mercadopago}prestashop>mercadopago_654acfab35ed25128a395562a4fe9b7c'] = 'Haz las pruebas que quieras.';
$_MODULE['<{mercadopago}prestashop>mercadopago_dc5b093bb61ae1c6bd43f46b8641c6e6'] = 'Access token - Sandbox';
$_MODULE['<{mercadopago}prestashop>mercadopago_e10357e9d093b953946d447ee8ae50d4'] = 'Con esta clave podrás recibir 
pagos reales de tus clientes.';
$_MODULE['<{mercadopago}prestashop>mercadopago_17ee48cfa6c5e758a7ba381897ab8985'] = 'Access token - Producción';
$_MODULE['<{mercadopago}prestashop>mercadopago_93027262f5c97f5faccac9eb7ef7df6d'] = 'Las credenciales no pueden 
estar vacías y deben ser válidas. ';
$_MODULE['<{mercadopago}prestashop>mercadopago_cbfa2a7c18db32aca0f634532701ee11'] = 'Por favor, complete sus 
credenciales para habilitar el módulo.';
$_MODULE['<{mercadopago}prestashop>mercadopago_416206518e27ed2ec8b8e0876078af35'] = 'Configuración básica';
$_MODULE['<{mercadopago}prestashop>mercadopago_49c557074b8d2bdb3ad51b3e0a7de714'] = 'Activar checkout';
$_MODULE['<{mercadopago}prestashop>mercadopago_d8bf0bd06048ac8cb87266046772cd15'] = 'Activa la experiencia de Mercado 
Pago en el checkout de tu tienda.';
$_MODULE['<{mercadopago}prestashop>mercadopago_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{mercadopago}prestashop>mercadopago_9f122d1b74cc2730551f41a39f024633'] = 'Este es el nombre que aparecerá 
en la factura de tus clientes.';
$_MODULE['<{mercadopago}prestashop>mercadopago_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Categoría';
$_MODULE['<{mercadopago}prestashop>mercadopago_7725eea7316b91a697529f861093031d'] = '¿A qué categoría pertenecen t
us productos?	';
$_MODULE['<{mercadopago}prestashop>mercadopago_a125e14c06e3cdcf245efc8fbf61d6d7'] = 'Elige la que mejor los 
caracteriza ';
$_MODULE['<{mercadopago}prestashop>mercadopago_3ff40f69e5d711bc1d6be4e77f035883'] = '(elija \"otro\" si su producto 
es demasiado específico).';
$_MODULE['<{mercadopago}prestashop>mercadopago_0da8d9a75492046bea7f314521e07cae'] = 'Medios de pago';
$_MODULE['<{mercadopago}prestashop>mercadopago_dd2360b0896865677612fc496a384b2c'] = 'Selecciona los medios de pago 
disponibles en tu tienda.';
$_MODULE['<{mercadopago}prestashop>mercadopago_011901666e08f84f38252b5321a7d4de'] = 'Activa las alternativas de pago 
que prefieras para tus clientes.';
$_MODULE['<{mercadopago}prestashop>mercadopago_3e8133cb8e813855808d2a5cd47ce9c8'] = 'Máximo de cuotas';
$_MODULE['<{mercadopago}prestashop>mercadopago_5cc9b560613b00fcc6e10883d4432b06'] = 'Cuál es el máximo de cuotas con 
las que un cliente puede comprar?';
$_MODULE['<{mercadopago}prestashop>mercadopago_4d9ac946f92f7211e40671513c72fd09'] = 'Ajustes guardados con éxito.';
$_MODULE['<{mercadopago}prestashop>mercadopago_119dd5a342e981b13bf0024d5c6a6933'] = 'Configuración avanzada';
$_MODULE['<{mercadopago}prestashop>mercadopago_2f8f0bf6cb50e8d4f7522de276e0760e'] = 'Volver a la tienda';
$_MODULE['<{mercadopago}prestashop>mercadopago_e9715a7f70ce5cf1cb518fd16d305fa1'] = '¿Quieres que tu cliente 
vuelva a ';
$_MODULE['<{mercadopago}prestashop>mercadopago_72bc674f60937edebc07087216b89279'] = 'la tienda después de finalizar 
la compra?';
$_MODULE['<{mercadopago}prestashop>mercadopago_deb43872e3df204974c85e5b07ad8576'] = 'Modo binario';
$_MODULE['<{mercadopago}prestashop>mercadopago_522c0cdc241fe3522f17b3ad2dedb4d4'] = 'Acepta y rechaza pagos de 
forma automática. ¿Quieres que lo activemos?';
$_MODULE['<{mercadopago}prestashop>mercadopago_e456b7ae55d4a9f901fb3470a128336e'] = 'Si activas el modo binario ';
$_MODULE['<{mercadopago}prestashop>mercadopago_b728e339b60d9c558fa1adcaec821df2'] = 'no podrás dejar pagos 
pendientes.';
$_MODULE['<{mercadopago}prestashop>mercadopago_fae58ca0f100ef36492bab55c890f905'] = 'Esto puede afectar la prevención 
de fraude.';
$_MODULE['<{mercadopago}prestashop>mercadopago_f80c4084ad08d222831157786724237a'] = 'Déjalo inactivo para estar 
respaldado por nuestra propia herramienta.';
$_MODULE['<{mercadopago}prestashop>mercadopago_415badd14ed9ac983761d77759ac01f1'] = 'Guarda las preferencias de 
pago durante';
$_MODULE['<{mercadopago}prestashop>mercadopago_9bc2c57ddfe686a3e1b65155bd23ed62'] = 'Los links de pago se generan 
cada vez que recibimos ';
$_MODULE['<{mercadopago}prestashop>mercadopago_0261973eee78952e25b28a80882fdf81'] = 'datos de una intención de 
compra de tus clientes. ';
$_MODULE['<{mercadopago}prestashop>mercadopago_79577d03ae0733b416527d51323c9f11'] = 'Guardamos esa información 
durante un período de tiempo para no ';
$_MODULE['<{mercadopago}prestashop>mercadopago_48988a3c2cf0901168963a2b77b49fd9'] = 'pedirle los datos cada vez que 
vuelve al proceso de compra.';
$_MODULE['<{mercadopago}prestashop>mercadopago_9392c6ee6236c7abc9caea38fc984392'] = 'Elige cuándo quieres que lo 
olvidemos.';
$_MODULE['<{mercadopago}prestashop>mercadopago_042f12563bb4eb10e00d61777a573e74'] = 'Sponsor ID';
$_MODULE['<{mercadopago}prestashop>mercadopago_67a10b694ba920e2ad489d7637b78db4'] = 'Con este número identificamos 
todas tus transacciones ';
$_MODULE['<{mercadopago}prestashop>mercadopago_9afe87955ead8ca6fec8dae9e5875b5c'] = 'y sabemos cuántas ventas 
procesamos con tu cuenta.';
$_MODULE['<{mercadopago}prestashop>mercadopago_36ac045205b16f9bb7cd8bb5641e839d'] = 'El tiempo para guardar las 
preferencias de pago ';
$_MODULE['<{mercadopago}prestashop>mercadopago_81495f3842f92cd64795702e235405e6'] = 'debe ser un número entero.';
$_MODULE['<{mercadopago}prestashop>mercadopago_3d971a385494ff0141522319fb83d18b'] = 'El Sponsor ID debe ser válido y ';
$_MODULE['<{mercadopago}prestashop>mercadopago_5f8ebd5334a69c027c4281054438cb1b'] = 'debe ser del mismo país que 
el vendedor.';
$_MODULE['<{mercadopago}prestashop>mercadopago_5ecdf7c8fed5fa55b341b963ae70790f'] = 'Gracias por calificarnos!';
$_MODULE['<{mercadopago}prestashop>mercadopago_aea84af3b9a9115bf366af2993aafe68'] = 'Transacción en Proceso';
$_MODULE['<{mercadopago}prestashop>mercadopago_5b3f086dfa19e142c8dd3dd4c3248379'] = 'Transacción Terminada';
$_MODULE['<{mercadopago}prestashop>mercadopago_f01f74aabecf111292f9b9e01027ae0c'] = 'Transacción Cancelada';
$_MODULE['<{mercadopago}prestashop>mercadopago_52c8fdd11601ff4aacfacba9cb00f873'] = 'Transacción Rechazada';
$_MODULE['<{mercadopago}prestashop>mercadopago_186177a57ee4cb741ba591e0259e871f'] = 'Transacción Reembolsada';
$_MODULE['<{mercadopago}prestashop>mercadopago_ab74c3411f6f46df16a6c47791be5a1b'] = 'Transacción Chargedback';
$_MODULE['<{mercadopago}prestashop>mercadopago_bf40a1c10d0b4a9cb26a27593226285b'] = 'Transacción en la Mediación';
$_MODULE['<{mercadopago}prestashop>mercadopago_53b4d02529d11ed85eb327d5297ec1ca'] = 'Transacción Pendiente';
$_MODULE['<{mercadopago}prestashop>mercadopago_2b39c27da5542ec1a72d8151ac607cd7'] = 'Transacción Autorizada';
$_MODULE['<{mercadopago}prestashop>mercadopago_8b144ffc87beff564884b1c190275539'] = 'Seleccionar país';
$_MODULE['<{mercadopago}prestashop>mercadopago_3536be57ce0713954e454ae6c53ec023'] = 'Argentina';
$_MODULE['<{mercadopago}prestashop>mercadopago_42537f0fb56e31e20ab9c2305752087d'] = 'Brasil';
$_MODULE['<{mercadopago}prestashop>mercadopago_2e6507f70a9cc26fb50f5fd82a83c7ef'] = 'Chile';
$_MODULE['<{mercadopago}prestashop>mercadopago_ef3388cc5659bccb742fb8af762f1bfd'] = 'Colombia';
$_MODULE['<{mercadopago}prestashop>mercadopago_8dbb07a18d46f63d8b3c8994d5ccc351'] = 'México';
$_MODULE['<{mercadopago}prestashop>mercadopago_84c8fa2341f7d052a1ee3a36ff043798'] = 'Peru';
$_MODULE['<{mercadopago}prestashop>mercadopago_75497a22409db78dcc52c291e078bc10'] = 'Uruguay';
$_MODULE['<{mercadopago}prestashop>mercadopago_e95294b730f61c8175550ec244bfcb50'] = 'Venezuela';
$_MODULE['<{mercadopago}prestashop>mercadopago_b496f2ac75f46ba34a01cd8c8e3aa58d'] = 'Seleccione la categoria';
$_MODULE['<{mercadopago}prestashop>mercadopago_0ac6aa5d88fa4e4ce0a4490dc73812f6'] = 'Quiero pagar con Mercado 
Pago sin costo adicional.';
$_MODULE['<{mercadopago}prestashop>standard_77faa1e2771d6e65932730c205fcdfc3'] = ' Este método de pago no está 
disponible.';
$_MODULE['<{mercadopago}prestashop>configure_93e79e63103bd12d684d29dd8c5f7db2'] = 'Configurar';
$_MODULE['<{mercadopago}prestashop>configure_ea6942b6e935d4f20f2f0aa0ab970786'] = 'Acerca de Mercado Pago';
$_MODULE['<{mercadopago}prestashop>configure_a58fb6f8d5fa325b8a565543ca270149'] = '¿En qué país opera tu cuenta de 
Mercado Pago?';
$_MODULE['<{mercadopago}prestashop>configure_39759c24a82b6d01f4df1a638e68c18f'] = 'Activa tus credenciales según 
lo que quieras hacer';
$_MODULE['<{mercadopago}prestashop>configure_a8849b8a280d035432791fbfdf0452c4'] = 'Realiza pruebas antes de salir 
al mundo.';
$_MODULE['<{mercadopago}prestashop>configure_d5b45a4ea17412944b2c05168cec89ca'] = 'Opera de dos formas';
$_MODULE['<{mercadopago}prestashop>configure_d827e868cfc70880feeca07abb364a75'] = 'Por defecto te dejamos';
$_MODULE['<{mercadopago}prestashop>configure_49d484110c1982dbdda0bc015dd9fb60'] = 'el modo Sandbox activo';
$_MODULE['<{mercadopago}prestashop>configure_7abba1e34fb6cad141e8dde084952a2f'] = 'para que hagas testeos antes 
de empezar a vender.';
$_MODULE['<{mercadopago}prestashop>configure_bd9e3654feb4f1c85ef1bf4fd97a207c'] = '¿Todo va bien?';
$_MODULE['<{mercadopago}prestashop>configure_af82753f7709e7925e08ef4e8bfa9799'] = 'Desactiva Sandbox ';
$_MODULE['<{mercadopago}prestashop>configure_e9ef61e532809013857dab3ad3b7f76a'] = 'al final de la configuración 
y abre paso a tus ventas online.';
$_MODULE['<{mercadopago}prestashop>configure_c94de0cea3cc6ee4dc150e61a987a537'] = 'Homologa tu cuenta, solo te 
llevará unos minutos.';
$_MODULE['<{mercadopago}prestashop>configure_8a63c2a2e98a89a3c6b073d2704dee7b'] = 'Completa este proceso para que 
podamos garantizar, juntos, ';
$_MODULE['<{mercadopago}prestashop>configure_b64323dd2a444f7e4fabf280f396ccb0'] = 'la seguridad de los datos de 
tus clientes y la adecuación ';
$_MODULE['<{mercadopago}prestashop>configure_daf2f0c60bc1529738c021561715ebd9'] = 'a las normas o disposiciones 
legales de cada país.';
$_MODULE['<{mercadopago}prestashop>configure_9dab17f93d30ea134605735a9b375c9d'] = 'Homologa mi cuenta';
$_MODULE['<{mercadopago}prestashop>configure_3a6784615aed38b088eb5de9427c0abf'] = 'Hagamos que tu cliente termine 
su compra de forma rápida, fácil y segura.';
$_MODULE['<{mercadopago}prestashop>configure_7729570d02a936c9302dd499ee604181'] = 'Selecciona pagos online';
$_MODULE['<{mercadopago}prestashop>configure_832d97c61d83bcbdcb3598d991ed7798'] = 'Selecciona pagos presenciales';
$_MODULE['<{mercadopago}prestashop>configure_be90e7ec3ba34cc1451181ce3bcadd6e'] = '¿Eres un partner de Mercado Pago?';
$_MODULE['<{mercadopago}prestashop>configure_86174edb875ef23dc3322ba661f309cc'] = 'Personaliza estas opciones y 
activa otras herramientas de nuestro módulo listas para usar.';
$_MODULE['<{mercadopago}prestashop>template_1_a92bebfa5f70a3786ea9953e1e9773d8'] = 'Diseña la mejor experiencia de 
pago para tus clientes';
$_MODULE['<{mercadopago}prestashop>template_1_6f634c53c8076146fc38c109ce2b48ff'] = 'Sigue estos pasos y maximiza 
tu conversión:';
$_MODULE['<{mercadopago}prestashop>template_1_bc83bf46a3e91a4a138ac2c07881bd02'] = 'Obtén tus';
$_MODULE['<{mercadopago}prestashop>template_1_747391bbc36c449de673db69e3911b33'] = 'credenciales';
$_MODULE['<{mercadopago}prestashop>template_1_10f5bb74039218e6fa8b06e5fef54b3e'] = 'en tu cuenta de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_1_bd2cbf52162163d3521a3895fbea1089'] = 'Homologa tu cuenta para 
poder cobrar.';
$_MODULE['<{mercadopago}prestashop>template_1_c52634eb3210dbfc991a1ac0f82b908c'] = 'Elige los';
$_MODULE['<{mercadopago}prestashop>template_1_202063371530d80c1194a9338bd1da0a'] = 'medios de pago';
$_MODULE['<{mercadopago}prestashop>template_1_bc52eba6d017a063fc65172092655fc4'] = 'disponibles en tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_1_fc0177e6038d03b3fcac6579880bb22d'] = 'Deja activo';
$_MODULE['<{mercadopago}prestashop>template_1_2652eec977dcb2a5aea85f5bec235b05'] = 'Sandbox';
$_MODULE['<{mercadopago}prestashop>template_1_6d7aeb981765e4ba0aa9bc097b0235c8'] = 'para testear compras en 
tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_1_bbe643f238828cfdd76a13721493073a'] = 'Desactívalo cuando veas 
que todo va bien y ¡empieza a recibir pagos!';
$_MODULE['<{mercadopago}prestashop>template_1_6f235ddc80153a4b89e18fd417cc9f13'] = 'Las credenciales son las 
claves que te proporcionamos para que integres de forma rápida y segura.';
$_MODULE['<{mercadopago}prestashop>template_1_24439d2083722f62f134e1af31af0b8b'] = 'Debes tener una cuenta 
homologada en Mercado Pago para cobrar en tu sitio web.';
$_MODULE['<{mercadopago}prestashop>template_1_6620af18731b27933e67b35fa05bdaac'] = 'No necesitas saber diseñar o 
programar para activar Mercado Pago en tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_1_51ea86a037206934591b9cc87a4f60cb'] = 'Credenciales';
$_MODULE['<{mercadopago}prestashop>template_1_85230d105b96581e53b7bc90c8e5a6fc'] = 'Activa tus credenciales según 
lo que quieras hacer.';
$_MODULE['<{mercadopago}prestashop>template_1_a8849b8a280d035432791fbfdf0452c4'] = 'Realiza pruebas antes de salir 
al mundo.';
$_MODULE['<{mercadopago}prestashop>template_1_b678a2968e7782b50ac679a7a174003a'] = 'Opera de dos formas:';
$_MODULE['<{mercadopago}prestashop>template_1_d827e868cfc70880feeca07abb364a75'] = 'Por defecto te dejamos';
$_MODULE['<{mercadopago}prestashop>template_1_49d484110c1982dbdda0bc015dd9fb60'] = 'el modo Sandbox activo';
$_MODULE['<{mercadopago}prestashop>template_1_7abba1e34fb6cad141e8dde084952a2f'] = 'para que hagas testeos antes 
de empezar a vender.';
$_MODULE['<{mercadopago}prestashop>template_1_bd9e3654feb4f1c85ef1bf4fd97a207c'] = '¿Todo va bien?';
$_MODULE['<{mercadopago}prestashop>template_1_af82753f7709e7925e08ef4e8bfa9799'] = 'Desactiva Sandbox';
$_MODULE['<{mercadopago}prestashop>template_1_e9ef61e532809013857dab3ad3b7f76a'] = 'al final de la configuración 
y abre paso a tus ventas online.';
$_MODULE['<{mercadopago}prestashop>template_1_0b383245aa069d810f6979510a868c9d'] = 'Quiero mis credenciales';
$_MODULE['<{mercadopago}prestashop>template_1_54c6b6eaf3e820eac371b80b2ba09276'] = 'Atención:';
$_MODULE['<{mercadopago}prestashop>template_1_6530042c062048e897dfdf4c008e85ef'] = 'Crea una cuenta en Mercado 
Pago para obtener tus credenciales.';
$_MODULE['<{mercadopago}prestashop>template_1_9d665fdfa656a4c08bde745b6521ba12'] = 'Homologa tu cuenta';
$_MODULE['<{mercadopago}prestashop>template_1_0822e306c64fda6b3ddf558c9d4e620d'] = 'en Mercado Pago para ir a 
Producción y cobrar en tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_1_ef5766369f7603bbba0c2e5018e1f92f'] = 'Prueba tu tienda';
$_MODULE['<{mercadopago}prestashop>template_1_8cf7c76bee7d5d01bdf8c3b2f45e3e5e'] = '¿Todo configurado? Ve a tu 
tienda en modo Sandbox';
$_MODULE['<{mercadopago}prestashop>template_1_1f0656e806fb5354d1f21e326f2250e5'] = 'Visita tu tienda como si fueras 
uno de tus mejores clientes.';
$_MODULE['<{mercadopago}prestashop>template_1_1dc218191be3aa450e22c5124f27ca68'] = 'Revisa que todo esté bien para 
impresionarlos y aumentar tus ventas.';
$_MODULE['<{mercadopago}prestashop>template_1_46ebbcbb39dbe344b4112cc0a5f666e7'] = 'Quiero testear mis ventas';
$_MODULE['<{mercadopago}prestashop>template_1_35e1af020b043e72d20163fbb8a908c2'] = 'Comienza a vender';
$_MODULE['<{mercadopago}prestashop>template_1_65e4cd45cf8c709bdcee07254d1af1ca'] = 'Todo listo para el despegue de 
tus ventas';
$_MODULE['<{mercadopago}prestashop>template_1_5c5ab638dec6d1d4bfb42a79096d0dc5'] = 'Ya saliste a Producción. Solo 
falta que tus mejores clientes lleguen a tu tienda';
$_MODULE['<{mercadopago}prestashop>template_1_32e244514f1309407819c213f8aa6d41'] = 'para vivir la mejor experiencia 
de compra online com Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_1_c53b75d25bbb29ea88cd39815c8cca9b'] = 'Visitar mi tienda';
$_MODULE['<{mercadopago}prestashop>template_1_fec7bfd4ce92341854141c772cfced43'] = '¿Algo anda mal? Ponte en';
$_MODULE['<{mercadopago}prestashop>template_1_016c818ab3066b069aea787977ebd732'] = 'contacto con nuestro soporte';
$_MODULE['<{mercadopago}prestashop>template_1_302922dc490cb64aeb79fb13b68dce29'] = 'Tu opinión nos ayuda a mejorar';
$_MODULE['<{mercadopago}prestashop>template_1_4dd2a3c8aa97501fad9c4adf8f1a8c08'] = 'Tu opinión nos ayuda a mejorar.';
$_MODULE['<{mercadopago}prestashop>template_1_31ac66d6c0c54df827401c7c406c99c4'] = 'Del 1 al 10, ¿qué tan probable es 
que recomiendes nuestro módulo a un amigo?';
$_MODULE['<{mercadopago}prestashop>template_1_6d7e95a18cbe54df868c80577562cd16'] = 'Nada probable';
$_MODULE['<{mercadopago}prestashop>template_1_fbebf1b9a7bf5a18d0f6fc9f6abc102a'] = 'Muy probable';
$_MODULE['<{mercadopago}prestashop>template_1_fb667de616cb5b65494a0910323a85c1'] = '¿Comentarios o sugerencias? Este 
es el espacio ideal:';
$_MODULE['<{mercadopago}prestashop>template_1_237299c5812c28bfc72d7c83aa4360e1'] = 'Escribe tu comentario';
$_MODULE['<{mercadopago}prestashop>template_1_92eb39a1407d02c39fc0403548241472'] = 'Cerrar';
$_MODULE['<{mercadopago}prestashop>template_1_30cc00aea30ec70b7c1292b6458181c0'] = 'Enviar';
$_MODULE['<{mercadopago}prestashop>template_2_054b087dd3b47354218fa0f43b0a4708'] = 'Procesa pagos y despega 
tus ventas';
$_MODULE['<{mercadopago}prestashop>template_2_290e8a62723c3a84f80b8e1f07daaabd'] = 'Oferece a tus clientes la mejor';
$_MODULE['<{mercadopago}prestashop>template_2_c790d4238533522db5aa8f28a319a660'] = 'experiencia de pago.';
$_MODULE['<{mercadopago}prestashop>template_2_44114119b17d0fe55fdf80221711f8ef'] = 'Configura Mercado Pago';
$_MODULE['<{mercadopago}prestashop>template_2_61b9503c89edd2355b888d0545522f89'] = 'Muestra tus promociones';
$_MODULE['<{mercadopago}prestashop>template_2_93c84aadfdcf07084e4f2fa679fe1f9b'] = 'y vende en cuotas con la';
$_MODULE['<{mercadopago}prestashop>template_2_ba82a7a32167c6a72ed449d880cb0dab'] = 'mejor financiación posible';
$_MODULE['<{mercadopago}prestashop>template_2_e32a6118d52f26c2eb196b2d65394091'] = 'Te cobraremos una comisión de 
cada pago que recibas.';
$_MODULE['<{mercadopago}prestashop>template_2_677869bd80212b711b55dd58bcf44477'] = '¿Cuáles son los beneficios de';
$_MODULE['<{mercadopago}prestashop>template_2_b5635a8fc063ce488e5a994868c7e237'] = 'cobrar con Mercado Pago?';
$_MODULE['<{mercadopago}prestashop>template_2_d7b08495839f19135437b5a4b34b6aa7'] = 'Cobra como quieras y vende 
sin límites.';
$_MODULE['<{mercadopago}prestashop>template_2_8bb68bfa72895b66857f58b5e90b24ab'] = 'Maximiza tu conversión con 
la mejor';
$_MODULE['<{mercadopago}prestashop>template_2_dfe1379b834b52a9194eb2b7a50cd7a9'] = 'Tienes herramientas listas 
para usar y';
$_MODULE['<{mercadopago}prestashop>template_2_a99d2075ea07f4066dfb98360cda9e03'] = 'especialistas dispuestos 
a ayudarte.';
$_MODULE['<{mercadopago}prestashop>template_2_35a19af2539ce2d73aa8e94001e8582e'] = '¿Cómo recibo los pagos?';
$_MODULE['<{mercadopago}prestashop>template_2_f3057eceb38b1f2570cfe0564c25f128'] = 'Tus clientes pagan con el';
$_MODULE['<{mercadopago}prestashop>template_2_ad4718e5b9d39d7ab6671d333ad17289'] = 'medio de pago que prefieran.';
$_MODULE['<{mercadopago}prestashop>template_2_8470dfa115ec61b0e44bb338e4c20c9f'] = 'El dinero se acredita en';
$_MODULE['<{mercadopago}prestashop>template_2_4a5aafba420663518704358f415b8ad5'] = 'tu cuenta de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_2_bd38ccbfe670ef60f74fd3c37c148da0'] = 'Una vez disponible,';
$_MODULE['<{mercadopago}prestashop>template_2_f49af6f3fe28621f5424652dc2ce5191'] = 'lo transfieres sin costo 
adicional a tu cuenta bancaria.';
$_MODULE['<{mercadopago}prestashop>template_2_2b473c9882ad1091929ee313be9883cd'] = '¿Qué puedo hacer con';
$_MODULE['<{mercadopago}prestashop>template_2_f5ff82c588f8831570514ba3997e2d6a'] = 'Mercado Pago en mi tienda?';
$_MODULE['<{mercadopago}prestashop>template_2_0eaca4c150937181c71bfd3d7cc9f0db'] = 'Compra con un click: recordamos';
$_MODULE['<{mercadopago}prestashop>template_2_06c448861ab3f6be22a6c5b017e37cc5'] = 'los datos tus usuarios logueados.';
$_MODULE['<{mercadopago}prestashop>template_2_d553b22924e8e98fe7dbe5a5f0110ec7'] = 'Pago como invitado: no hace 
falta que tus';
$_MODULE['<{mercadopago}prestashop>template_2_8be2ccf6e848695e714d535a25a67497'] = 'clientes abran una cuenta en 
Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_2_c9823f1d462a2eb1813a8321d1d3ed14'] = 'Devolución de pagos y 
cancelación';
$_MODULE['<{mercadopago}prestashop>template_2_9cf2536dbde2e5cf62c4dc9c3d1fc231'] = 'de pagos pendientes.';
$_MODULE['<{mercadopago}prestashop>template_2_ef074d1ddbc9d8400db915195e6ed39d'] = 'Crecer está en tus manos.';
$_MODULE['<{mercadopago}prestashop>template_2_e3566653fc0aef95a7d7d315db6c2e20'] = 'Oferece a tus clientes';
$_MODULE['<{mercadopago}prestashop>template_2_77b80c41245412c4b855488db4375312'] = 'una experiencia de pago única.';
$_MODULE['<{mercadopago}prestashop>template_2_9ddc064e4a2b1e2cb30dd09fbcfe1b54'] = 'Somos partners oficiales de 
Prestashop.';
$_MODULE['<{mercadopago}prestashop>template_2_4d970c15a397054cf9c4fd1b9cd45702'] = 'Conoce nuestro Programa de 
Protección de vendedores.';
$_MODULE['<{mercadopago}prestashop>failure_c31dfc53931a8b1ba122531de0411682'] = '¡Ops! Ha ocurrido un error en su 
pago, intente nuevamente...';
$_MODULE['<{mercadopago}prestashop>payment_seven_6c3a31fbf585951de547b0b6e3ee9efb'] = 'Usa el medio de pago que 
prefieras.';
$_MODULE['<{mercadopago}prestashop>payment_seven_97d230ba10188a678071024e4805424d'] = 'Tarjetas de crédito';
$_MODULE['<{mercadopago}prestashop>payment_seven_3ac951fa50bfee3a2c0b93c24bc4e713'] = 'Hasta';
$_MODULE['<{mercadopago}prestashop>payment_seven_bc9ed44b2c8ce57b8269b08e91a808e6'] = 'cuotas';
$_MODULE['<{mercadopago}prestashop>payment_seven_4974f75f42d810732cb09c6f360a2495'] = 'Tarjetas de débito';
$_MODULE['<{mercadopago}prestashop>payment_seven_14bc8945586a3e80a4fe5ef10b2ebbb3'] = 'Pagos en efectivo';
$_MODULE['<{mercadopago}prestashop>payment_seven_aa7069457a14a017ca2c07f837b6807a'] = 'Te llevamos a nuestro sitio 
para completar el pago';
$_MODULE['<{mercadopago}prestashop>payment_six_34668e92624aa2651438132d59851fe5'] = 'Quiero pagar con Mercado Pago 
sin costo adicional.';
$_MODULE['<{mercadopago}prestashop>payment_six_6c3a31fbf585951de547b0b6e3ee9efb'] = 'Usa el medio de pago que 
prefieras.';
$_MODULE['<{mercadopago}prestashop>payment_six_97d230ba10188a678071024e4805424d'] = 'Tarjetas de crédito';
$_MODULE['<{mercadopago}prestashop>payment_six_3ac951fa50bfee3a2c0b93c24bc4e713'] = 'Hasta';
$_MODULE['<{mercadopago}prestashop>payment_six_bc9ed44b2c8ce57b8269b08e91a808e6'] = 'cuotas';
$_MODULE['<{mercadopago}prestashop>payment_six_4974f75f42d810732cb09c6f360a2495'] = 'Tarjetas de débito';
$_MODULE['<{mercadopago}prestashop>payment_six_14bc8945586a3e80a4fe5ef10b2ebbb3'] = 'Pagos en efectivo';
